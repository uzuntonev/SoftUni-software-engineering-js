const mongoose = require('mongoose');

const animalSchema = new mongoose.Schema({
    //TODO: Implement me
});

const Animal = mongoose.model('Animal', animalSchema);
module.exports = Animal;